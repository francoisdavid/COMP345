//
//  MainGameLoop.cpp
//  A2_Part_3
//
//  Created by Wilson Fong on 2019-11-01.
//  Copyright © 2019 Wilson Fong. All rights reserved.
//

#include "MainGameLoop.hpp"
#include <cmath>
#include <string.h>
#include <vector>

using namespace std;

// Constructor
MainGameLoop::MainGameLoop(HandObject *handObj, vector<Player*> playersList) {
    handObject = handObj;
    players = playersList;

    // Initialize
    setup();
}

// Destructor
MainGameLoop::~MainGameLoop() {
    delete handObject;
    delete head;
    players.clear();
};

// Add players to the game
void MainGameLoop::setup() {
    cout << endl << "Setting game up..." << endl;
    Turn *last = NULL;
    
    for (int i = 0; i < players.size(); i++) {
        last = addToEnd(last, players.at(i));
        
        // Set head to first added player
        if (head == NULL) {
            head = last;
        }
    }
    
    // Start game with the first player
    executeGameLoop(last);
}

// Add to beginning of empty circular linked list
Turn *MainGameLoop::addToEmpty(Turn* last, Player* player)
{
    if (last != NULL)
        return last;
    
    Turn *temp = new Turn();
    
    // Assign player data
    temp -> player = player;
    last = temp;
    
    // Creating the link
    last -> next = last;
    
    return last;
}

// Add to the end of circular linked list
Turn *MainGameLoop::addToEnd(Turn *last, Player* player)
{
    if (last == NULL)
        return addToEmpty(last, player);
    
    Turn *temp = new Turn();
    
    // Assign player data
    temp -> player = player;
    
    // Adjusting the links
    temp -> next = last -> next;
    last -> next = temp;
    last = temp;
    
    return last;
}

// Game loop remains in its execution phase until compute game score determines winner
void MainGameLoop::executeGameLoop(Turn *last) {
    cout << "Running game loop..." << endl;
    int roundCounter =  1;
    try {
        while (true) {
            cout << endl << "ROUND " << roundCounter<< " STARTS" << endl;
            traverse(last);
            roundCounter++;
        }
    } catch (const std::exception& ex) {
        cout << endl << ex.what() << endl;
    }

    cout << endl << "GAME IS OVER." << endl;
}

// Going through each player for each round
void MainGameLoop::traverse(Turn *last)
{
    Turn *p;
    
    if (last == NULL)
    {
        cout << "List is empty." << endl;
        return;
    }
    
    // Pointing to first node of the list
    p = last -> next;
    
    // Perform action when traversing the list
    do
    {
        // Display who's player's turn it is.
        cout << endl << "It is " << p->player->getName() << "'s turn to play now. This player's current bank account shows: " << *p->player->getPlayerCoins()<<"$. "<< endl;

        // Initialize it to a number that will make it enter the while loop.
        int indexOfCard = -1 ;
        handObject->toString();
        // Select one of the six cards facing up (if it is a computer player). Else let the user choose.
        if(p->player->isGreedyComputer() || p->player->isModerateComputer()) {
            // Randomize the card picked.
            indexOfCard = rand() % 5;
        } else {
            // Prompt the user to enter the card he wants to select, continues this process until the input is valid.
            while(indexOfCard > 5 || indexOfCard < 0 || *p->player->getPlayerCoins() < ceil(double(indexOfCard)/2)) {
                cout << "Please enter the index of the card you want to select (1 to 6) : ";
                cin >> indexOfCard;
                indexOfCard -=1;
                // Display to the user that he does not have enough coins for that.
                if(*p->player->getPlayerCoins() < ceil(double(indexOfCard)/2) ){
                    cout<< "You can't afford this card." << endl;
                }
            }
        }
        Card *card = handObject->getCard(indexOfCard);

        p->player->BuyCard(indexOfCard);

        // Display the card chosen.
        cout << "\tGood: " << card->getGoods() << "\tAction: " << card->getAction() << endl;


        processCard(card, p->player);



        // Check to see if the deck is empty.
        if (handObject->getDeckCount() > 0) {
            // Next player's turn
            p = p -> next;
        } else {
            throw invalid_argument("Deck of cards is finished. The game is over.");
        }
    } while(p != last->next);
}

void MainGameLoop::processCard(Card*  card, Player* player) {
    string action  = card->getAction();

    if(action == "Build City."){
        cout << "Here are the countries you have that do not already have a city." << endl;
        vector<Army*> armyLoc = player->getPlayerArmies();
        for(int i = 0 ; i < armyLoc.size(); i++ ){
            cout << i+1 << "- " << *armyLoc.at(i)->getLocation()->getName() <<endl;
        }
        cout << armyLoc.size()+1 << "- Ignore the action" << endl;
        int index = 0 ;
        cout<< "Where do you want to build that city? " ;
        cin >> index;
        index -=1;
        while(index < 0 || index > armyLoc.size()){
            cout<<"Not a valid region! Re-enter the index of the region where you want to build a city: ";
            cin >> index;
            index -=1;
        }
        if( index!=armyLoc.size()) {
            playerActions->BuildCity(armyLoc.at(index)->getLocation(), player);
            cout << player->getName() <<" built a city on " << *armyLoc.at(index)->getLocation()->getName()<< "." <<endl;
        }else {
            cout << "Action was ignored." << endl;
        }

    } else if (action == "Move 5 armies."){
        cout << "You can now move 5 armies. Here are the armies you have that you can move."<< endl;
        // Get the regions of the current player.
        vector<Node*> regions = player->getCountries();
        for(int i = 0 ; i < regions.size(); i++ ){
            cout << i+1 << "- " << regions.at(i)->getName() <<endl;
        }
    }
}