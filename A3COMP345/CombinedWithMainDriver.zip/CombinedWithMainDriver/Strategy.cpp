//
// Created by Francois David on 2019-11-15.
//

#include "Strategy.h"
