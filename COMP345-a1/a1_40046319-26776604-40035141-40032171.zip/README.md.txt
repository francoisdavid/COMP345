# COMP345
8 Minutes Empire Game

Assignment 1. COMP345 || CONCORDIA UNIVERSITY || October 12th, 2019.

Students: 
Francois David: 40046319
Wilson Fong: 26776604
Rami El-Kazma: 40035141
Iana Belitchka: 40032171

INSTRUCTIONS:
The files related to a specific Task # are in the Task # folder. Header files
from different tasks use other header files, so it is important that Task files
remain intact so that '#include' works properly.
