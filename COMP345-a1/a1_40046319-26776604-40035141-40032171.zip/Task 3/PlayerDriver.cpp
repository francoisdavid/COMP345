#include "Player.h"
#include <vector>
#include <iostream>
using namespace std;

int main(int argc, const char* argv[]) {
	
	Player *player = new Player("Player 1", 10, 18, 7, 1992);

	player->printInfo();
	cout << endl;

	//Demonstrating the cards owned by a player
	cout << player->getName() << " will add a card to his collection..." << endl;
	player->BuyCard(1);
	cout << "Card: Action: " << player->getCards()[0]->getAction() << "; Good: " << player->getCards()[0]->getGoods() << endl;
	cout << player->getName() << " now has " << *player->getPlayerCoins() << " coins." << endl;
	cout << endl;

	//Demonstrating the PayCoin() method
	cout << player->getName() << " pays 5 coins..." << endl;
	player->PayCoin(5);
	cout << player->getName() << " now has " << *player->getPlayerCoins() << " coins." << endl;
	cout << endl;

	//Demonstrating the Bid() method
	cout << player->getName() << " bids 2 coins..." << endl;
	player->Bid(2);
	cout << endl;

	//Demonstrating the countries owned by a player
	Node* country = new Node(1, "Canada");
	player->addCountry(country);
	cout << player->getName() << " owns " << *player->getCountries()[0]->getName() << "." << endl;

	//Demonstrating the implemented player methods
	player->BuildCity();
	player->DestroyArmy();
	player->MoveArmies();
	player->MoveOverLandOrWater();
	player->PlaceNewArmies();
	cout << endl;

	return 0;

}