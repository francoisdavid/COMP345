//
//  main.cpp
//  BidingT5A1
//
//  Created by Francois David on 2019-10-09.
//  Copyright © 2019 Francois David. All rights reserved.
//

#include "BidingFacility.h"
#include <iostream>
#include <vector>
#include <iostream>
using namespace std;


int main(int argc, const char * argv[]) {
    
    // Create a few players to test the biding facility.
    Player* player1 = new Player();
    Player* player2 = new Player();
    Player* player3 = new Player();
    Player* player4 = new Player();

    // Set their age.
    player1->setPlayerAge(3);
    player2->setPlayerAge(1);
    player3->setPlayerAge(2);
    player4->setPlayerAge(5);

	// Set their coins.
	player1->setPlayerCoins(10);
	player2->setPlayerCoins(10);
	player3->setPlayerCoins(10);
	player4->setPlayerCoins(10);
    
    // Create a new biding facility.
    BidingFacility* bf = new BidingFacility();
    
    // Make the players bid.
    bf->playerBid(player1, 11);
    bf->playerBid(player2, 0);
    bf->playerBid(player3, 0);
    bf->playerBid(player4, 3);
    
    cout << "\nNormal case where they bid different amount but one player bids more than he has." << endl;
    // Reveal the highest bider and display its name.
    Player* winner = bf->revailHighestBider();
	    
    cout << "\tWinner is : " << winner->getName() << endl;
	cout << winner->getName() << " now has " << *winner->getPlayerCoins() << " coins." << endl;
	cout << endl;
    
    BidingFacility* bf1 = new BidingFacility();
    
    
    bf1->resetCurrentBid();
    bf1->playerBid(player1, 0);
    bf1->playerBid(player2, 0);
    bf1->playerBid(player3, 0);
    bf1->playerBid(player4, 0);
    
    
    cout << "\nCase where they all bid zero, so the youngest is choosen (player2)." << endl;
    winner = bf1->revailHighestBider();
    cout << "\tWinner is : " << winner->getName() << endl;
	cout << winner->getName() << " now has " << *winner->getPlayerCoins() << " coins." << endl;
	cout << endl;
    
    
    bf1->resetCurrentBid();
    bf1->playerBid(player1, 5);
    bf1->playerBid(player2, 1);
    bf1->playerBid(player3, 4);
    bf1->playerBid(player4, 5);
    
    
    cout << "\nCase where there is a tie between 2 players, so the youngest is choosen as the winner (player1)." << endl;
    winner = bf1->revailHighestBider();
    cout << "\tWinner is : " << winner->getName() << endl;
	cout << winner->getName() << " now has " << *winner->getPlayerCoins() << " coins." << endl;
    
    return 0;
}
